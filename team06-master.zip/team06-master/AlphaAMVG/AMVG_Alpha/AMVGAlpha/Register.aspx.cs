﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AMVGAlpha.AMVGRef;

namespace AMVGAlpha
{
    public partial class Register : System.Web.UI.Page
    {
        private Service1Client userReg = new Service1Client();
        protected void Page_Load(object sender, EventArgs e)
        {
            /*if (Session["Auth"].ToString() != "2")
            {
                Response.Redirect("index.aspx");
            }*/
        }

        protected void submit(object sender, EventArgs e)
        {
 
       
        }

        protected void Unnamed4_Click(object sender, EventArgs e)
        {
            if (userReg.RegisterUser(txtname.Text, txtsurname.Text, txtaddress.Text, txtemail.Text, txtpass.Text, txtcell.Text, DropDown1.SelectedItem.ToString().ToUpper()) == true)
            {
               // Response.Write("Registration successful");
                Response.Redirect("RegSuccess.aspx");

            }
       
        }
    }
}