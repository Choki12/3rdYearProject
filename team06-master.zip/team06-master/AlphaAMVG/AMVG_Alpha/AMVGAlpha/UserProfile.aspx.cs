﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AMVGAlpha.AMVGRef;
namespace AMVGAlpha
{
    public partial class UserProfile : System.Web.UI.Page
    {
        Service1Client User = new Service1Client();
        protected void Page_Load(object sender, EventArgs e)
        {
            string switchup = "";
            int counter = 0;
            string UID = User.GetUserByEmail(Session["Email"].ToString()).UserID.ToString();

            switchup +=
                "<div class='form - group'>< label class='col-md-4 control-label' for='Name (Full name)' id='lblname' runat='server'>Name: "+ User.GetUserByID(UID).Name + " " + User.GetUserByID(UID).Surname + "</label></div>"
                + "<div class='form - group'><label class='col - md - 4 control - label col - xs - 12' for='Home Address' id='lbladdress' runat='server'>Home Address: " + User.GetUserByID(UID).Address + "</label></div>"
                + "<div class='form - group'><label class='col - md - 4 control - label' for='Phone number ' id='lblphoneNumber' runat='server'>Phone number: " + User.GetUserByID(UID).CellNum + "</label></div>"
                + "<div class='form - group'><label class='col - md - 4 control - label' for='Email Address' id='lblemail' runat='server'>Email Address" + User.GetUserByID(UID).Email + "</label></div>"
                + "<div class='form - group'> <label class='col - md - 4 control - label' for='Password' id='lblpass' runat='server'>Password: " + User.GetUserByID(UID).Password + "</label></div>";

            counter++;
        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {

        }
    }
}