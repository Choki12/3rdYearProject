﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AMVGAlpha.AMVGRef;
namespace AMVGAlpha
{
    public partial class Login : System.Web.UI.Page
    {
        private Service1Client userLog = new Service1Client();
        protected void Page_Load(object sender, EventArgs e)
        {
          
        }

        protected void SignIn(object sender, EventArgs e)
        {
            string username = txtusername.Text;
            string pass = txtpass.Text;
            //string userType;

            if (userLog.UserLogin(username, pass) == true)
            {
               // if ((username) == (userLog.GetUserByEmail(username).Email))
                //{
                    //farmer logged in  
                    Session["FullName"] = userLog.GetUserByEmail(username).Name + " " + userLog.GetUserByEmail(username).Surname;
                    Session["Email"] = userLog.GetUserByEmail(username).Email;
                    Session["ID"] = userLog.GetUserByEmail(username).UserID;
                    Session["Auth"] = userLog.GetUserByEmail(username).Auth;
                    Session["UserType"] = userLog.GetUserByEmail(username).UserType;

                    if(Session["UserType"].ToString() == "FARMER")
                    {
                        Response.Write("Login Successful");
                        Response.Redirect("FarmerProfileFinal.aspx");
                    }
                    else if(Session["UserType"].ToString() == "VENDOR")
                    {
                        Response.Redirect("ViewUserProfile.aspx");
                    }
                    else
                    {
                        Response.Write("Login unsuccessful"); //try altering html elements to show password or email is wrong
                    }
                    


        
            }
        }
    }
}