﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AMVGAlpha.AMVGRef;
using System.Text;
using System.IO;
using System.Data;

namespace AMVGAlpha
{
    public partial class FarmerProfileFinal : System.Web.UI.Page
    {
        Service1Client Farmer = new Service1Client();

        static DataTable table1 = new DataTable("StockTable");
        static DataSet set = new DataSet("DStock");

        protected void Page_Load(object sender, EventArgs e)
        {
            string switchup = "";
            string switchup2 = "";
            string switchup3 = "";
            int counter = 0;
            string UID = Farmer.GetUserByEmail(Session["Email"].ToString()).UserID.ToString();


            switchup +=
                //"<div class='nav - side - menu' id='menuside' runat='server'><h4 class='card - title text - center' runat='server'>" + Farmer.GetUserByID(UID).Name + " " + Farmer.GetUserByID(UID).Surname + "</h4></div>" +
                //"<div id='ProfileDiv' runat='server'><div class='container'><div class='row'><div class='col - md - 5  toppad pull-right col - md - offset - 3 '><p class=' text - info' id='date' runat='server'>" + DateTime.Now.ToShortDateString() + "</p></div></div></div></div>" +
                "<h3 class='panel - title' id ='UserName'>" + " " + "Profile: " + Farmer.GetUserByID(UID).Name + " " + Farmer.GetUserByID(UID).Surname + "</h3>"
                + "<div class=' col - md - 9 col - lg - 9 ' runat='server'>"
                + "<table class='table table-user - information'>"
                + "<tbody>"
                + " <tr><td>Address: </ p ></td><td>" + Farmer.GetUserByID(UID).Address + "</td></tr>"
                + " <tr><td>Cellphone Number: </ p ></td><td>" + Farmer.GetUserByID(UID).CellNum + "</td></tr>"
                + " <tr><td>Email: </ p ></td><td>" + Farmer.GetUserByID(UID).Email + "</td></tr></tbody></table>";


            switchup2 +=
                "<h4 id='h4thing' runat='server style='color: black''>" + Farmer.GetUserByID(UID).Name + " " + Farmer.GetUserByID(UID).Surname + "</h4>";
            h4thing.InnerHtml = switchup2;

            switchup3 +=
                " <div class='col - md - 5  toppad pull-right col - md - offset - 3 '><p class=' text - info' id='date' runat='server'>" + "Logged in on: "+ DateTime.Now.ToShortDateString() + "</p></div>";

            date.InnerHtml = switchup3;
            UserName.InnerHtml = switchup;
            counter++;
            LoadStockData();
            
        }

        protected void logout_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Session.RemoveAll();
            Session.Abandon();
            Session.Contents.RemoveAll();
            this.Page.Session.Clear();
            Response.Redirect("Login.aspx");
        }

        protected void logout2Click(object sender, EventArgs e)
        {
            Session.Clear();
            Session.RemoveAll();
            Session.Abandon();
            Session.Contents.RemoveAll();
            this.Page.Session.Clear();
            Response.Redirect("Login.aspx");
        }

        protected void LoadStock_Click(object sender, EventArgs e)
        {
            AddStock();
        }

        protected void LoadStockData()
        {
            
             string switchup = "";
            //string key = "";
            int counter = 0;
            string UID = Farmer.GetUserByEmail(Session["Email"].ToString()).UserID.ToString();

            List<Products> products = new List<Products>();
            products.AddRange(Farmer.GetProducts(UID));
            //Products b = new Products();
            Products b = Farmer.GetStock(UID);

           // while(counter > 0)
           // {
                switchup += //"<div class='card - body' id='dvTable' runat='server'>" +
             "<div id='table' class='table - editable' runat='server'>" +
             "<span class='table - add float-right mb - 3 mr - 2'><a href='#!' class='text-success'><i class='fa fa-plus fa-2x' aria-hidden='true'></i></a></span>"
             + "<table class='table table-bordered table - responsive - md table - striped text - center'>"
             + "<tr>" +
             "<th class='text - center'>Name</th>" +
              "<th class='text - center'>Weight</th>" +
              "<th class='text - center'>SellByDate</th>" +
              "<th class='text - center'>Description</th>" +
              "<th class='text - center'>Qty</th>" +
              "<th class='text - center'>Price</th>" +
              "<th class='text - center'>Remove</th>" +
              "</tr>" +
              "<tr id='changeValues' runat='server'>" +
              " <td class='pt - 3 - half' contenteditable='true'>" + b.PName + "</td>"
             + " <td class='pt - 3 - half' contenteditable='true'>" + b.PMass.ToString() + "</td>"
             + " <td class='pt - 3 - half' contenteditable='true'>" + b.PSell_By_Date + "</td>"
             + " <td class='pt - 3 - half' contenteditable='true'>" + b.PDescription + "</td>"
             + " <td class='pt - 3 - half' contenteditable='true'>" + "1" + "</td>"
             + " <td class='pt - 3 - half' contenteditable='true'>" + b.PPrice.ToString() + "</td>"
             + "<td class='pt - 3 - half'>"
             + "<span class='table - up'><a href='#!' class='indigo-text'><i class='fa fa-long-arrow-up' aria-hidden='true'></i></a></span>"
             + "<span class='table - down'><a href='#!' class='indigo-text'><i class='fa fa-long-arrow-down' aria-hidden='true'></i></a></span>"
             + "</td>"
             + "<td>"
             + "<span class='table - remove'><button type='button' class='btn btn-danger btn - rounded btn - sm my - 0'>Remove</button></span>"
             + "</td>"
             + "</tr>"
             + "<tr>"
             + "</table>"
             + "</div>"
             + "</div>";
                //+ "</div>";

                
            //}
            counter++;
            dvTable.InnerHtml = switchup;
            //changeValues.InnerHtml = switchup;

        }

        public void AddStock()
        {
            string UID = Farmer.GetUserByEmail(Session["Email"].ToString()).UserID.ToString();
            Products b = Farmer.GetStock(UID);

            Int32 Rcount = Convert.ToInt32(table1.Rows.Count);

            if (Rcount == 0)
            {

                table1.Columns.Add("Product Name");
                table1.Columns.Add("Product Mass");
                table1.Columns.Add("Sell By Date");
                table1.Columns.Add("Description");
                table1.Columns.Add("Price");
                table1.Rows.Add();
                set.Tables.Add(table1);
            }
            else
            {
                
                    DataRow dr = table1.NewRow();
                    dr["Product Name"] = b.PName;
                    dr["Product Mass"] = b.PMass;
                    dr["Sell by Date"] = b.PSell_By_Date;
                    dr["Description"] = b.PDescription;
                    dr["Price"] = b.PPrice;
                    table1.Rows.Add(dr);
                
            }
            
        }
    }
}