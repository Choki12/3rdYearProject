{
    "": {
        "Content-Transfer-Encoding": "8bit",
        "Content-Type": "text/plain; charset=UTF-8",
        "Language-Team": "LANGUAGE <LL@li.org>",
        "Last-Translator": "Alberto Fernandez <afernandez@coffeecup.com>",
        "MIME-Version": "1.0",
        "PO-Revision-Date": "2012-09-18 16:34+0100",
        "POT-Creation-Date": "YEAR-MO-DA HO:MI+ZONE",
        "Project-Id-Version": "PACKAGE VERSION"
    }
}