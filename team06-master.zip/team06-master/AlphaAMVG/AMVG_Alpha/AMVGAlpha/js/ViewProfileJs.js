﻿$(function () {
    var Accordion = function (el, multiple) {
        this.el = el || {};
        this.multiple = multiple || false;

        // Variables privadas
        var links = this.el.find('.link');
        // Evento
        links.on('click', { el: this.el, multiple: this.multiple }, this.dropdown)
    }

    Accordion.prototype.dropdown = function (e) {
        var $el = e.data.el;
        $this = $(this),
            $next = $this.next();

        $next.slideToggle();
        $this.parent().toggleClass('open');

        if (!e.data.multiple) {
            $el.find('.submenu').not($next).slideUp().parent().removeClass('open');
        };
    }

    var accordion = new Accordion($('#accordion'), false);

});
function addTable() {
    $('#Table').append('<div class="divTableRow">' + '<div class="divTableCell">' + '#addName' + '</div><div class="divTableCell">' + '#addQty' + '</div><div class="divTableCell">' + '#addPrice' + '</div><div class="divTableCell">' + '<asp:Button ID="btndelete" runat="server" Text="Delete" />' + '</div></div></div>');

}




