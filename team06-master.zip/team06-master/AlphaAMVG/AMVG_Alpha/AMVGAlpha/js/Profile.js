   var x = document.getElementById('StockDiv');
	var p = document.getElementById('EditStockDiv');
 var T = document.getElementById('ProfileDiv');
 var O = document.getElementById('OrdersDiv');
 function StockDis(){
   var x = document.getElementById('StockDiv');
	var p = document.getElementById('EditStockDiv');
	 var T = document.getElementById('ProfileDiv');
	  var O = document.getElementById('OrdersDiv');
	  O.style.display = 'none' ;
	 T.style.display = 'none' ;
	p.style.display = 'none' ;
	
	
    if (x.style.display === 'none') {
		
		
			
        x.style.display = 'block';
	
		
    } else {
        x.style.display = 'block';
		
    }
}
 function EditStockDis(){
  var x = document.getElementById('StockDiv');
	var p = document.getElementById('EditStockDiv');
	var T = document.getElementById('ProfileDiv');
	 var O = document.getElementById('OrdersDiv');
	  O.style.display = 'none' ;
	 T.style.display = 'none' ;
	x.style.display = 'none';
	
	
    if (p.style.display === 'none') {
       


	   p.style.display = 'block';
		
		
		
		
		
		
		
		
    } else {
		
        p.style.display = 'block';
		
    }
}

 function ProfileDis(){
	  var T = document.getElementById('ProfileDiv');
  var x = document.getElementById('StockDiv');
	var p = document.getElementById('EditStockDiv');
	 var O = document.getElementById('OrdersDiv');
	  O.style.display = 'none' ;
	x.style.display = 'none';
	p.style.display = 'none' ;
    if (T.style.display === 'none') {
       


	   T.style.display = 'block';
		
		
		
		
		
		
		
		
    } else {
		
        T.style.display = 'block';
		
    }
}
function OrdersDis(){
	  var T = document.getElementById('ProfileDiv');
  var x = document.getElementById('StockDiv');
	var p = document.getElementById('EditStockDiv');
	 var O = document.getElementById('OrdersDiv');
	  T.style.display = 'none' ;
	x.style.display = 'none';
	p.style.display = 'none' ;
    if (O.style.display === 'none') {
       


	   O.style.display = 'block';
		
		
		
		
		
		
		
		
    } else {
		
        O.style.display = 'block';
		
    }
}

$(document).ready(function() {
    $('[id^=detail-]').hide();
    $('.toggle').click(function() {
        $input = $( this );
        $target = $('#'+$input.attr('data-toggle'));
        $target.slideToggle();
    });
});