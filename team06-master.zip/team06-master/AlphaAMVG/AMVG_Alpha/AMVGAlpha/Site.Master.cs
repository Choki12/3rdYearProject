﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AMVGAlpha.AMVGRef;
namespace AMVGAlpha
{
    public partial class Site : System.Web.UI.MasterPage
    {
        private Service1Client userLog = new Service1Client();
        protected void Page_Load(object sender, EventArgs e)
        {
            logout2.Visible = false;
            name1.Visible = false;
            edt1.Visible = false;
            if (Session["Email"] != null)
            {
                name1.InnerHtml += "<div class='agile-login'><ul><li id='name1' runat='server'>Logged in as: " + Session["FullName"].ToString() + "</ul></div>";
                logout2.Visible = true;
                Log1.Visible = false;
                edt1.Visible = true;
            }
            /*else
            {
                //logout1.Visible = false;
                name1.Visible = false;
                edt1.Visible = false;
            }*/

            /*if (Session["Auth"].ToString() == "2")
            {
                Reg1.Visible = true;
            }
            else
            {
                Reg1.Visible = false;
            }*/
        }

       

        protected void cart_click(object sender, EventArgs e)
        {

        }

   
    }
}