﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AMVGAlpha.AMVGRef; 
namespace AMVGAlpha
{
    
    public partial class ViewProfile : System.Web.UI.Page
    {
        //we load the farmer details onto the page 
        Service1Client GetFarmer = new Service1Client();
        protected void Page_Load(object sender, EventArgs e)
        {
            titleChange();
            string switchup = "";
            int counter = 0;
            string UID = GetFarmer.GetUserByEmail(Session["Email"].ToString()).UserID.ToString();

            switchup

                  += "<div class='link'><i class='fa fa-globe'></i>Details: " + GetFarmer.GetUserByID(UID).Name + " " + GetFarmer.GetUserByID(UID).Surname +
                  "<i class='fa fa-chevron - down'></i></div>"
                  + "<ul class='submenu'>"
                  + "<li id='Date'><a href='#'><i class='fa fa-calendar left-none'></i> Cell Number: " + GetFarmer.GetUserByID(UID).CellNum + "</a></li>"
                  + "<li id='Address'><a href='#'>" + GetFarmer.GetUserByID(UID).Address + "</a></li>"
                  + "<li id='email'><a href='email.com'>Email: " + GetFarmer.GetUserByID(UID).Email + "</a></li>"
                  + "</ul>";


            FarmerDetails.InnerHtml = switchup;
            counter++;
        }

        protected void addStock(object sender, EventArgs e)
        {

            string fullcon = "";
            int counter = 0;
            string uid = GetFarmer.GetUserByEmail(Session["Email"].ToString()).UserID;

            fullcon += "<span class='popuptext' id='myPopup'>No stock added...</span>";

            string status;
            status = GetFarmer.AddStock(addname.Text,addtype.Text, addsellbydate.Text, Convert.ToDouble(addweight.Text), adDescription.Text, Convert.ToDouble(addPrice.Text),uid);

            if(status == "Stock Added")
            {
                fullcon+= "<span class='popuptext' id='myPopup'>Stock successfully added...</span>";
            }
            //Pop.InnerHtml = fullcon;
            counter++;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
          
        }


        protected void titleChange()
        {
            string switchup2 = "";
            int counter = 0;
            string UID = GetFarmer.GetUserByEmail(Session["Email"].ToString()).UserID.ToString();

            switchup2

                += "<div class = 'username'><h2>Name: " + GetFarmer.GetUserByID(UID).Name + " " + GetFarmer.GetUserByID(UID).Surname + " " + "<small><i class= 'fa fa-map-marker'></i>"
                + "Location: " + GetFarmer.GetUserByID(UID).Address + " " + "</small></h2><p><i class='fa fa-briefcase'></i>Welcome!</p>";

            usersplash.InnerHtml = switchup2;
            counter++;

        }
    }
}