﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AMVGAlpha.AMVGRef;

namespace AMVGAlpha
{
    public partial class ViewUserProfile : System.Web.UI.Page
    {
        Service1Client GetUser = new Service1Client();
        protected void Page_Load(object sender, EventArgs e)
        {
            titleChange();
            string switchup = "";
            
            int counter = 0;
            string UID = GetUser.GetUserByEmail(Session["Email"].ToString()).UserID.ToString();

            switchup

                  += "<div class='link'><i class='fa fa-globe'></i>Details: " + GetUser.GetUserByID(UID).Name + " " + GetUser.GetUserByID(UID).Surname +
                  "<i class='fa fa-chevron - down'></i></div>"
                  + "<ul class='submenu'>"
                  + "<li id='Date'><a href='#'><i class='fa fa-calendar left-none'></i> Cell Number: " + GetUser.GetUserByID(UID).CellNum + "</a></li>"
                  + "<li id='Address'><a href='#'>" + GetUser.GetUserByID(UID).Address + "</a></li>"
                  + "<li id='email'><a href='email.com'>Email: " + GetUser.GetUserByID(UID).Email + "</a></li>"
                  + "</ul>";


            userdetails.InnerHtml = switchup;
            counter++;
        }

        protected void titleChange()
        {
            string switchup2 = "";
            int counter = 0;
            string UID = GetUser.GetUserByEmail(Session["Email"].ToString()).UserID.ToString();

            switchup2

                += "<div class = 'username'><h2>Name: " + GetUser.GetUserByID(UID).Name + " " + GetUser.GetUserByID(UID).Surname + " " + "<small><i class= 'fa fa-map-marker'></i>"
                + "Location: " + GetUser.GetUserByID(UID).Address + " " + "</small></h2><p><i class='fa fa-briefcase'></i>Welcome!</p>";

            usersplash.InnerHtml = switchup2;
            counter++;

        }
    }
}