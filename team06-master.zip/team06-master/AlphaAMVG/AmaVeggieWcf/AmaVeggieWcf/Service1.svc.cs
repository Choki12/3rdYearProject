﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;


namespace AmaVeggieWcf
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {

        SqlCommand command;
        SqlDataReader reader;
        SqlConnection Connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\DBVeggie.mdf;Integrated Security=True");

        bool worked = false;
        string isUploaded;
      

        public string GetData(int value)
        {
            return string.Format("You entered: {0}", value);
        }

        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            if (composite == null)
            {
                throw new ArgumentNullException("composite");
            }
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
            }
            return composite;
        }
        /*******************************************************************************************************************************************************************/

        public bool Login(string Username, string password)
        {
            string qryStr = "SELECT * FROM Farmer ";

            this.command = new SqlCommand(qryStr);
            this.command.CommandType = CommandType.Text;
            this.command.Connection = Connection;
            this.command.Connection.Open();
            this.command.ExecuteNonQuery();
            this.reader = command.ExecuteReader();

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    if ((reader["FEmail"].ToString() == Username) && (reader["Password"].ToString() == password))
                    {
                        worked = true;
                    }

                    /*if((reader["VEmail"].ToString() == Username) && (reader["VPassword"].ToString() == password))
                    {
                        worked = true;
                    }*/

         
                }
            }

            this.Connection.Close();

            this.command.Connection.Close();
            this.command.Dispose();
            this.Connection.Dispose();
            return worked;
            
        }

        public bool UserLogin(string Username, string password)
        {
            string qryStr = "SELECT * FROM [User]";

            this.command = new SqlCommand(qryStr);
            this.command.CommandType = CommandType.Text;
            this.command.Connection = Connection;
            this.command.Connection.Open();
            this.command.ExecuteNonQuery();
            this.reader = command.ExecuteReader();

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    if ((reader["Email"].ToString() == Username) && (reader["Password"].ToString() == password))
                    {
                        worked = true;
                    }

                }
            }

            this.Connection.Close();

            this.command.Connection.Close();
            this.command.Dispose();
            this.Connection.Dispose();
            return worked;

        }

        public bool RegisterUser(string name, string surname, string address, string email, string password, string cellnumber, string typeUser)
        {
            KeyGenerator f = new KeyGenerator();
            string k = f.RandomString(5, true);//random pk for each farmer registered
            string ImgName = "pic.jpg";
            string qryStr = "INSERT INTO [User] VALUES (@UserID,@Name,@Surn,@Address,@Email,@Password,@Image,@CellNumber,@Auth,@TypeUser)";
            int Auth = 1;


            this.command = new SqlCommand(qryStr);
            this.command.CommandType = CommandType.Text;
            this.command.Connection = Connection;
            this.command.Connection.Open();



            this.command.Parameters.AddWithValue("@UserID", k);
            this.command.Parameters.AddWithValue("@Name", name);
            this.command.Parameters.AddWithValue("@Surn", surname);
            this.command.Parameters.AddWithValue("@Address", address);
            this.command.Parameters.AddWithValue("@Email", email);
            this.command.Parameters.AddWithValue("@Password", password);
            this.command.Parameters.AddWithValue("@Image", ImgName);
            this.command.Parameters.AddWithValue("@CellNumber", cellnumber);
            this.command.Parameters.AddWithValue("@Auth", Auth);
            this.command.Parameters.AddWithValue("@TypeUser", typeUser.ToUpper());

            this.command.ExecuteNonQuery();

            this.Connection.Close();


            return true;
        }

        /*Register Farmer*/
        public bool RegisterFarmer(string name, string surname, string address, string email, string password, string cellnumber)
        {

            KeyGenerator f = new KeyGenerator();
            string k = f.RandomString(5, true);//random pk for each farmer registered
            string ImgName = "pic.jpg";
            string qryStr = "INSERT INTO Farmer VALUES (@FarmerID,@FName,@FSurn,@FAddress,@FEmail,@Password,@FImage,@FCellNumber,@FAuth)";
            int Auth = 1;


            this.command = new SqlCommand(qryStr);
            this.command.CommandType = CommandType.Text;
            this.command.Connection = Connection;
            this.command.Connection.Open();
       
            

            this.command.Parameters.AddWithValue("@FarmerID", k);
            this.command.Parameters.AddWithValue("@FName", name);
            this.command.Parameters.AddWithValue("@FSurn", surname);
            this.command.Parameters.AddWithValue("@FAddress", address);
            this.command.Parameters.AddWithValue("@FEmail", email);
            this.command.Parameters.AddWithValue("@Password", password);
            this.command.Parameters.AddWithValue("@FImage", ImgName);
            this.command.Parameters.AddWithValue("@FCellNumber", cellnumber);
            this.command.Parameters.AddWithValue("@FAuth", Auth);

            this.command.ExecuteNonQuery();

            this.Connection.Close();

            
            return true; 
        }

        /*Register vendor*/
        public bool RegisterVendor(string name, string surname, string address, string email, string password, string cellnumber)
        {

            KeyGenerator v = new KeyGenerator();
            string k = v.RandomString(5, true);//random pk for each farmer registered
            string ImgName = "pic.jpg";
            string qryStr = "INSERT INTO Vendor VALUES (@VendorID,@VName,@VSurname,@VAddress,@VEmail,@VPassword,@VImage,@VCellNumber,@VAuth)";
            int Auth = 1;


            this.command = new SqlCommand(qryStr);
            this.command.CommandType = CommandType.Text;
            this.command.Connection = Connection;
            this.command.Connection.Open();



            this.command.Parameters.AddWithValue("@VendorID", k);
            this.command.Parameters.AddWithValue("@VName", name);
            this.command.Parameters.AddWithValue("@VSurname", surname);
            this.command.Parameters.AddWithValue("@VAddress", address);
            this.command.Parameters.AddWithValue("@VEmail", email);
            this.command.Parameters.AddWithValue("@VPassword", password);
            this.command.Parameters.AddWithValue("@VImage", ImgName);
            this.command.Parameters.AddWithValue("@VCellNumber", cellnumber);
            this.command.Parameters.AddWithValue("@VAuth", Auth);

            this.command.ExecuteNonQuery();

            this.Connection.Close();


            return true;
        }

        public Farmers GetFarmerID(string email)
        {
            
            string qrystr = ("SELECT FarmerID FROM Farmer WHERE FEmail ='" + email + "'");

            this.command = new SqlCommand(qrystr);
            this.command.CommandType = CommandType.Text;
            this.command.Connection = Connection;
            this.command.Connection.Open();

            reader = command.ExecuteReader(CommandBehavior.CloseConnection);

            Farmers fr = new Farmers();

            while(reader.Read())
            {
                fr.F_Name = reader["FarmerID"].ToString();
            }

            this.Connection.Close();

            this.command.Connection.Close();
            this.command.Dispose();
            this.Connection.Dispose();

            return fr;
        }

        public Vendors GetVendorID(string email)
        {

            string qrystr = ("SELECT VendorID FROM Vendor WHERE VEmail ='" + email + "'");

            this.command = new SqlCommand(qrystr);
            this.command.CommandType = CommandType.Text;
            this.command.Connection = Connection;
            this.command.Connection.Open();

            reader = command.ExecuteReader(CommandBehavior.CloseConnection);

            Vendors vr = new Vendors();

            while (reader.Read())
            {
                vr.VendorID = reader["VendorID"].ToString();

            }

            this.Connection.Close();

            this.command.Connection.Close();
            this.command.Dispose();
            this.Connection.Dispose();

            return vr;
        }

        public Farmers GetFarmerByEmail(string email)
        {
            string qrystr = ("SELECT * FROM Farmer WHERE FEmail ='" + email + "'");

            this.command = new SqlCommand(qrystr);
            this.command.CommandType = CommandType.Text;
            this.command.Connection = Connection;
            this.command.Connection.Open();

            reader = command.ExecuteReader(CommandBehavior.CloseConnection);

            Farmers fr = new Farmers();

            while (reader.Read())
            {
                fr.FarmerID = reader["FarmerID"].ToString();
                fr.F_Name = reader["FName"].ToString();
                fr.F_Surname = reader["FSurn"].ToString();
                fr.F_Address = reader["FAddress"].ToString();
                fr.F_Email = reader["FEmail"].ToString();
                fr.F_Password = reader["Password"].ToString();
                fr.F_Image = reader["FImage"].ToString();
                fr.F_CellNum = reader["FCellNumber"].ToString();

            }

            this.Connection.Close();

            this.command.Connection.Close();
            this.command.Dispose();
            this.Connection.Dispose();

            return fr;

        }

        public Vendors GetVendorByEmail(string email)
        {
            string qrystr = ("SELECT * FROM Vendor WHERE VEmail ='" + email + "'");

            this.command = new SqlCommand(qrystr);
            this.command.CommandType = CommandType.Text;
            this.command.Connection = Connection;
            this.command.Connection.Open();

            reader = command.ExecuteReader(CommandBehavior.CloseConnection);

            Vendors vr = new Vendors();

            while (reader.Read())
            {
                vr.V_Name = reader["VName"].ToString();
                vr.V_Surname = reader["VSurname"].ToString();
                vr.V_Address = reader["VAddress"].ToString();
                vr.V_Email = reader["VEmail"].ToString();
                vr.V_Password = reader["VPassword"].ToString();
                vr.V_Image = reader["VImage"].ToString();
                vr.V_CellNum = reader["VCellNumber"].ToString();

            }

            this.Connection.Close();

            this.command.Connection.Close();
            this.command.Dispose();
            this.Connection.Dispose();

            return vr;
        }

        public string GetFarmerDP(string ShowDisplay, string ID)
        {
            string qry = "SELECT * FROM [Farmer] WHERE FEmail='" + ID + "'";

            this.command = new SqlCommand(qry);
            this.command.CommandType = CommandType.Text;
            this.command.Connection = Connection;
            this.command.Connection.Open();
            this.command.ExecuteNonQuery();
            this.reader = command.ExecuteReader();

            ShowDisplay = "";
            string Image = "";

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    Image = reader["FImage"].ToString();

                }
            }


            string DisplayinnerHtm = "";

            DisplayinnerHtm = ShowDisplay;


            this.Connection.Close();

            this.command.Connection.Close();
            this.command.Dispose();
            this.Connection.Dispose();

            return Image;
        }

        public string GetVendorDP(string ShowDisplay, string ID)
        {
            string qry = "SELECT * FROM [Vendor] WHERE VEmail='" + ID + "'";

            this.command = new SqlCommand(qry);
            this.command.CommandType = CommandType.Text;
            this.command.Connection = Connection;
            this.command.Connection.Open();
            this.command.ExecuteNonQuery();
            this.reader = command.ExecuteReader();

            ShowDisplay = "";
            string Image = "";

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    Image = reader["VImage"].ToString();

                }
            }


            string DisplayinnerHtm = "";

            DisplayinnerHtm = ShowDisplay;


            this.Connection.Close();

            this.command.Connection.Close();
            this.command.Dispose();
            this.Connection.Dispose();

            return Image;
        }

        public string UploadFarmerDp(string filename, string ID)
        {

            string qry = "UPDATE [Farmer] SET FImage =@FImage WHERE FarmerID='" + ID + "'";

            this.command = new SqlCommand(qry);
            this.command.CommandType = CommandType.Text;
            this.command.Connection = Connection;

            this.command.Parameters.AddWithValue("@FImage", filename);

            isUploaded = "true";
            this.command.Connection.Open();
            this.command.ExecuteNonQuery();
            this.command.Connection.Close();
            this.command.Dispose();

            this.Connection.Dispose();

            return isUploaded;
        }

        public string UploadVendorDp(string filename, string ID)
        {
            string qry = "UPDATE [Vendor] SET VImage =@VImage WHERE VendorID='" + ID + "'";

            this.command = new SqlCommand(qry);
            this.command.CommandType = CommandType.Text;
            this.command.Connection = Connection;

            this.command.Parameters.AddWithValue("@VImage", filename);

            isUploaded = "true";
            this.command.Connection.Open();
            this.command.ExecuteNonQuery();
            this.command.Connection.Close();
            this.command.Dispose();

            this.Connection.Dispose();

            return isUploaded;
        }

        public string ChangeFarmerPassword(string password, string ID)
        {
            string qry = "UPDATE [Farmer] SET Password =@Password WHERE FarmerID='" + ID + "'";


            this.command = new SqlCommand(qry);
            this.command.CommandType = CommandType.Text;
            this.command.Connection = Connection;

            this.command.Parameters.AddWithValue("@Password", password);

            this.command.Connection.Open();
            this.command.ExecuteNonQuery();
            this.command.Connection.Close();
            this.command.Dispose();

            this.Connection.Dispose();

            return "Password Updated";
        }

        public string ChangeVendorPassword(string password, string ID)
        {
            string qry = "UPDATE [Vendor] SET VPassword =@VPassword WHERE VendorID='" + ID + "'";


            this.command = new SqlCommand(qry);
            this.command.CommandType = CommandType.Text;
            this.command.Connection = Connection;

            this.command.Parameters.AddWithValue("@VPassword", password);

            this.command.Connection.Open();
            this.command.ExecuteNonQuery();
            this.command.Connection.Close();
            this.command.Dispose();

            this.Connection.Dispose();

            return "Password Updated";
        }

        public string EditFarmerProfile(string cellnumber, string address, string ID)
        {
            string qry = "UPDATE[Farmer] SET FCellNumber = @FCellNumber, FAddress = @FAddress WHERE FarmerID = '" + ID + "'";


            this.command = new SqlCommand(qry);
            this.command.CommandType = CommandType.Text;
            this.command.Connection = Connection;

            this.command.Parameters.AddWithValue("@FCellNumber", cellnumber);
            this.command.Parameters.AddWithValue("@FAddress", address);

            this.command.Connection.Open();
            this.command.ExecuteNonQuery();
            this.command.Connection.Close();
            this.command.Dispose();

            this.Connection.Dispose();

            return "Farmer Profile Updated";
        }

        public string EditVendorProfile(string cellnumber, string address, string ID)
        {
            string qry = "UPDATE[Vendor] SET VCellNumber = @VCellNumber, VAddress = @VAddress WHERE VendorID = '" + ID + "'";


            this.command = new SqlCommand(qry);
            this.command.CommandType = CommandType.Text;
            this.command.Connection = Connection;

            this.command.Parameters.AddWithValue("@VCellNumber", cellnumber);
            this.command.Parameters.AddWithValue("@VAddress", address);

            this.command.Connection.Open();
            this.command.ExecuteNonQuery();
            this.command.Connection.Close();
            this.command.Dispose();

            this.Connection.Dispose();

            return "Farmer Profile Updated";
        }

        public string AddtoCart(string CartID, int Quantity, string VendorID, string OrderID)
        {
            string cart_id = CartID;
            int size = Quantity;
            string vendor_id = VendorID;
            string order_id = OrderID;

            string qrystring = "INSERT INTO Cart VALUES (@cart_id,@size,@vendor_id,@order_id)";


            command = new SqlCommand(qrystring);
            this.command.CommandType = System.Data.CommandType.Text;
            this.command.Connection = Connection;

            this.command.Parameters.AddWithValue("@cart_id", cart_id);
            this.command.Parameters.AddWithValue("@size", size);
            this.command.Parameters.AddWithValue("@vendor_id", vendor_id);
            this.command.Parameters.AddWithValue("@order_id", order_id);


            this.command.Connection.Open();

            this.command.ExecuteNonQuery();
            this.command.Connection.Close();

            return "Added items to cart";
        }


        public string AddStock(string PName, string PType, string PSellByDate, double PMass, string PDescription, double PPrice, string UserID)
        {

            KeyGenerator f = new KeyGenerator();
            string k = f.RandomString(3, true);//random pk for each farmer registered
            
            string qryStr = "INSERT INTO Produce VALUES (@ProduceID,@P_NAME,@PTYPE,@P_SELLBYDATE,@P_MASS,@P_DESCRIPTION,@P_PRICE,@UserID)";

            this.command = new SqlCommand(qryStr);
            this.command.CommandType = CommandType.Text;
            this.command.Connection = Connection;
            this.command.Connection.Open();



            this.command.Parameters.AddWithValue("@ProduceID",k);
            this.command.Parameters.AddWithValue("@P_NAME", PName);
            this.command.Parameters.AddWithValue("@PTYPE", PType);
            this.command.Parameters.AddWithValue("@P_SELLBYDATE", PSellByDate);
            this.command.Parameters.AddWithValue("@P_MASS", PMass);
            this.command.Parameters.AddWithValue("@P_DESCRIPTION", PDescription);
            this.command.Parameters.AddWithValue("@P_PRICE", PPrice);
            this.command.Parameters.AddWithValue("@UserID", UserID);


            this.command.ExecuteNonQuery();

            this.Connection.Close();
            return "Stock Added";
        }

        public List<Orders> ShowCart(string VendorID)
        {
            throw new NotImplementedException();

        }

        public string PlaceOrder(string ProduceID, string VendorID)
        {
            throw new NotImplementedException();
        }

        public List<Orders> GetOrder(string VendorID)
        {
            string qry = "SELECT * FROM [Orders] where VendorID=" + VendorID;

            this.command = new SqlCommand(qry);
            this.command.CommandType = CommandType.Text;
            this.command.Connection = Connection;
            this.command.Connection.Open();

            reader = this.command.ExecuteReader();

            List<Orders> OrderList = new List<Orders>();

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    Orders orders = new Orders();

                    orders.Order_ID = reader["OrderID"].ToString();
                    orders.Farmer_ID = reader["FarmerID"].ToString();
                    orders.Produce_ID = reader["ProduceID"].ToString();
                    orders.Vendor_ID = reader["VendorID"].ToString();
                    orders.DateTime = reader["O_DATE_TIME"].ToString();

                    OrderList.Add(orders);


                }

                this.Connection.Close();

                this.command.Connection.Close();
                this.command.Dispose();
                this.Connection.Dispose();

                

            }
            return OrderList;
        }

        public Farmers GetFarmerByID(string id)
        {
            string qrystr = ("SELECT * FROM Farmer WHERE FarmerID ='" + id + "'");

            this.command = new SqlCommand(qrystr);
            this.command.CommandType = CommandType.Text;
            this.command.Connection = Connection;
            this.command.Connection.Open();

            reader = command.ExecuteReader(CommandBehavior.CloseConnection);

            Farmers fr = new Farmers();

            while (reader.Read())
            {
                fr.FarmerID = reader["FarmerID"].ToString();
                fr.F_Name = reader["FName"].ToString();
                fr.F_Surname = reader["FSurn"].ToString();
                fr.F_Address = reader["FAddress"].ToString();
                fr.F_Email = reader["FEmail"].ToString();
                fr.F_Password = reader["Password"].ToString();
                fr.F_Image = reader["FImage"].ToString();
                fr.F_CellNum = reader["FCellNumber"].ToString();

            }

            this.Connection.Close();

            this.command.Connection.Close();
            this.command.Dispose();
            this.Connection.Dispose();

            return fr;
        }

        public Vendors GetVendorByID(string id)
        {
            string qrystr = ("SELECT * FROM Vendor WHERE VendorID ='" + id + "'");

            this.command = new SqlCommand(qrystr);
            this.command.CommandType = CommandType.Text;
            this.command.Connection = Connection;
            this.command.Connection.Open();

            reader = command.ExecuteReader(CommandBehavior.CloseConnection);

            Vendors vr = new Vendors();

            while (reader.Read())
            {
                vr.V_Name = reader["VName"].ToString();
                vr.V_Surname = reader["VSurname"].ToString();
                vr.V_Address = reader["VAddress"].ToString();
                vr.V_Email = reader["VEmail"].ToString();
                vr.V_Password = reader["VPassword"].ToString();
                vr.V_Image = reader["VImage"].ToString();
                vr.V_CellNum = reader["VCellNumber"].ToString();

            }

            this.Connection.Close();

            this.command.Connection.Close();
            this.command.Dispose();
            this.Connection.Dispose();

            return vr;
        }

        public User GetUserByID(string id)
        {
            string qrystr = ("SELECT * FROM [User] WHERE UserID ='" + id + "'");

            this.command = new SqlCommand(qrystr);
            this.command.CommandType = CommandType.Text;
            this.command.Connection = Connection;
            this.command.Connection.Open();

            reader = command.ExecuteReader(CommandBehavior.CloseConnection);

            User u = new User();

            while (reader.Read())
            {
                u.Name = reader["Name"].ToString();
                u.Surname = reader["Surn"].ToString();
                u.Address = reader["Address"].ToString();
                u.Email = reader["Email"].ToString();
                //u.Password = reader["Password"].ToString();
                u.Image = reader["Image"].ToString();
                u.CellNum = reader["CellNumber"].ToString();
                u.Auth = Convert.ToInt32(reader["Auth"].ToString());
                u.UserType = reader["TypeUser"].ToString();

            }

            this.Connection.Close();

            this.command.Connection.Close();
            this.command.Dispose();
            this.Connection.Dispose();

            return u;
        }

        public User GetUserByEmail(string email)
        {
            string qrystr = ("SELECT * FROM [User] WHERE Email ='" + email + "'");

            this.command = new SqlCommand(qrystr);
            this.command.CommandType = CommandType.Text;
            this.command.Connection = Connection;
            this.command.Connection.Open();

            reader = command.ExecuteReader(CommandBehavior.CloseConnection);

            User u = new User();

            while (reader.Read())
            {
                u.UserID = reader["UserID"].ToString();
                u.Name = reader["Name"].ToString();
                u.Surname = reader["Surn"].ToString();
                u.Address = reader["Address"].ToString();
                u.Email = reader["Email"].ToString();
                //u.Password = reader["Password"].ToString();
                u.Image = reader["Image"].ToString();
                u.CellNum = reader["CellNumber"].ToString();
                u.Auth = Convert.ToInt32(reader["Auth"].ToString());
                u.UserType = reader["TypeUser"].ToString();

            }

            this.Connection.Close();

            this.command.Connection.Close();
            this.command.Dispose();
            this.Connection.Dispose();

            return u;
        }

        public List<Products> GetProducts(string UID)
        {
            string qry = "SELECT * FROM [Produce] ";

            command = new SqlCommand(qry);
            this.command.CommandType = CommandType.Text;
            this.command.Connection = Connection;
            this.command.Connection.Open();

            reader = this.command.ExecuteReader();
            List<Products> ProductList = new List<Products>();

            if(reader.HasRows)
            {
                while(reader.Read())
                {
                    Products prod = new Products();
                    prod.Produce_ID = reader["ProduceID"].ToString();
                    prod.PName = reader["P_NAME"].ToString();
                    prod.PType = reader["PTYPE"].ToString();
                    prod.PSell_By_Date = reader["P_SELLBYDATE"].ToString();
                    prod.PMass = Convert.ToDouble(reader["P_MASS"].ToString());
                    prod.PDescription = reader["P_DESCRIPTION"].ToString();
                    prod.PPrice = Convert.ToDouble(reader["P_PRICE"].ToString());
                    prod.UserID = reader["UserID"].ToString();

                    ProductList.Add(prod);
                }
                this.Connection.Close();
                this.command.Connection.Close();
                this.command.Dispose();
                this.Connection.Dispose();

            }
            return ProductList;
        }

        public Products GetStock(string UID)
        {
            
            string qry = "SELECT * FROM [Produce] WHERE UserID ='" + UID + "'";

            command = new SqlCommand(qry);
            this.command.CommandType = CommandType.Text;
            this.command.Connection = Connection;
            this.command.Connection.Open();

            reader = this.command.ExecuteReader();
            Products prod = new Products();

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    prod.Produce_ID = reader["ProduceID"].ToString();
                    prod.PName = reader["P_NAME"].ToString();
                    prod.PType = reader["PTYPE"].ToString();
                    prod.PSell_By_Date = reader["P_SELLBYDATE"].ToString();
                    prod.PMass = Convert.ToDouble(reader["P_MASS"].ToString());
                    prod.PDescription = reader["P_DESCRIPTION"].ToString();
                    prod.PPrice = Convert.ToDouble(reader["P_PRICE"].ToString());
                    prod.UserID = reader["UserID"].ToString();   
                }
                this.Connection.Close();
                this.command.Connection.Close();
                this.command.Dispose();
                this.Connection.Dispose();
            }
            return prod;
        }

        public bool UpdateUser(string UID, string name, string surname, string address, string email, string password, string cellnumber, string imgName)
        {
            string qry = "UPDATE [User] SET Name = @Name, Surn = @Surn, Address = @Address, Password = @Password, Image = @Image, CellNumber = @CellNumber WHERE UserID = '" + UID + "'";

            this.command = new SqlCommand(qry);
            this.command.CommandType = CommandType.Text;
            this.command.Connection = Connection;

            this.command.Parameters.AddWithValue("@Name", name);
            this.command.Parameters.AddWithValue("@Surn", surname);
            this.command.Parameters.AddWithValue("@Address", address);
            this.command.Parameters.AddWithValue("@Password", password);
            this.command.Parameters.AddWithValue("@Image", imgName);
            this.command.Parameters.AddWithValue("@CellNumber", cellnumber);

            this.command.Connection.Open();
            this.command.ExecuteNonQuery();
            this.command.Connection.Close();
            this.command.Dispose();

            this.Connection.Dispose();
            return true;
        }
    }
}
