﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace AmaVeggieWcf
{
    public class Vendors
    {
        private string vendorID { get; set; }
        private string v_name { get; set; }
        private string v_surname { get; set; }
        private string v_email { get; set; }
        private string v_address { get; set; }
        private string v_pass { get; set; }
        private string v_image { get; set; }
        private string v_cellnum { get; set; }
        private int v_auth { get; set; }

        public string VendorID
        {
            set
            {
                vendorID = value;
            }

            get
            {
                return vendorID;
            }
        }

        public string V_Name
        {
            set
            {
                v_name = value;
            }

            get
            {
                return v_name;
            }
        }


        public string V_Surname
        {
            set
            {
                v_surname = value;
            }

            get
            {
                return v_surname;
            }
        }


        public string V_Email
        {
            set
            {
                v_email = value;
            }

            get
            {
                return v_email;
            }
        }


        public string V_Address
        {
            set
            {
                v_address = value;
            }

            get
            {
                return v_address;
            }
        }

        public string V_Image
        {
            set
            {
                v_image = value;
            }

            get
            {
                return v_image;
            }
        }

        public string V_Password
        {
            set
            {
                v_pass = value;
            }

            get
            {
                return v_pass;
            }
        }

        public string V_CellNum
        {
            set
            {
                v_cellnum = value;
            }

            get
            {
                return v_cellnum;
            }
        }

        public int V_Auth
        {
            set
            {
                v_auth = value;
            }

            get
            {
                return v_auth;
            }
        }

    }
}