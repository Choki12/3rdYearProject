﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AmaVeggieWcf
{
    public class Products
    {
        private string user_ID { get; set; }
        private string produce_ID { get; set; }
        private string p_name { get; set; }
        private string ptype { get; set; }
        private string psellbydate { get; set; }
        private double pmass { get; set; }
        private string pdescription { get; set; }
        private double p_price { get; set; }


        public string UserID
        {
            set
            {
                user_ID = value;
            }

            get
            {
                return user_ID;
            }
        }

        public string Produce_ID
        {
            set
            {
                produce_ID = value;
            }

            get
            {
                return produce_ID;
            }
        }

        public string PType
        {
            set
            {
                ptype = value;
            }

            get
            {
                return ptype;
            }
        }


        public string PName
        {
            set
            {
                p_name = value;
            }

            get
            {
                return p_name;
            }
        }

        public string PSell_By_Date
        {
            set
            {
                psellbydate = value;
            }

            get
            {
                return psellbydate;
            }
        }

        public double PMass
        {
            set
            {
                pmass = value;
            }

            get
            {
                return pmass;
            }
        }

        public string PDescription
        {
            set
            {
                pdescription = value;
            }

            get
            {
                return pdescription;
            }
        }


        public double PPrice
        {
            set
            {
                p_price = value;
            }

            get
            {
                return p_price;
            }
        }

    }
}