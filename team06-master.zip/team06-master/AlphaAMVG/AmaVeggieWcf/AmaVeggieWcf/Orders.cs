﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AmaVeggieWcf
{
    public class Orders
    {
        private string order_ID { get; set; }
        private string farmer_ID { get; set; }
        private string produce_ID { get; set; }
        private string vendor_ID { get; set; }
        private string datetime { get; set; }


        public string Order_ID
        {
            set
            {
                order_ID = value;
            }
            get
            {
                return order_ID;
            }
        }


        public string Farmer_ID
        {
            set
            {
                farmer_ID = value;
            }
            get
            {
                return farmer_ID;
            }
        }

        public string Produce_ID
        {
            set
            {
                produce_ID = value;
            }
            get
            {
                return produce_ID;
            }
        }


        public string Vendor_ID
        {
            set
            {
                vendor_ID = value;
            }
            get
            {
                return vendor_ID;
            }
        }

        public string DateTime
        {
            set
            {
                datetime = value;
            }
            get
            {
                return datetime;
            }
        }



    }
}
