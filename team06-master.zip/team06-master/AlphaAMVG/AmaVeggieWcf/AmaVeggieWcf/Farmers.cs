﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace AmaVeggieWcf
{
    public class Farmers
    {
        private string farmerID {get;set;}
        private string f_name { get; set; }
        private string f_surname { get; set; }
        private string f_email { get; set; }
        private string f_address { get; set; }
        private string f_pass { get; set; }
        private string f_image { get; set; }
        private string f_cellnum { get; set; }
        private int f_auth { get; set; }

        public string FarmerID
        {
            set
            {
                farmerID = value;
            }

            get
            {
                return farmerID;
            }
        }

        public string F_Name
        {
            set
            {
                f_name = value;
            }

            get
            {
                return f_name;
            }
        }


        public string F_Surname
        {
            set
            {
                f_surname = value;
            }

            get
            {
                return f_surname;
            }
        }


        public string F_Email
        {
            set
            {
                f_email = value;
            }

            get
            {
                return f_email;
            }
        }


        public string F_Address
        {
            set
            {
                f_address = value;
            }

            get
            {
                return f_address;
            }
        }

        public string F_Password
        {
            set
            {
                f_pass = value;
            }

            get
            {
                return f_pass;
            }
        }

        public string F_Image
        {
            set
            {
                f_image = value;
            }

            get
            {
                return f_image;
            }
        }

        public string F_CellNum
        {
            set
            {
                f_cellnum = value;
            }

            get
            {
                return f_cellnum;
            }
        }

        public int F_Auth
        {
            set
            {
                f_auth = value;
            }

            get
            {
                return f_auth;
            }
        }

    }
}