﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AmaVeggieWcf
{
    //Show specials on catalogue items 
    public class CatalogueGenerator
    {

    }
}