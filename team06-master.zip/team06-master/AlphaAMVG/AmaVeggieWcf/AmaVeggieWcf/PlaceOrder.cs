﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AmaVeggieWcf
{
    public class PlaceOrder
    {
        private string order_ID { get; set; }
        private string user_ID { get; set; }
        private string produce_ID { get; set; }
        private string datetime { get; set; }
        private int o_pending { get; set; }
        private int o_received { get; set; }
        private int o_accept { get; set; }
        private int o_deny { get; set; }


        public string Order_ID
        {
            set
            {
                order_ID = value;
            }
            get
            {
                return order_ID;
            }
        }


        public string User_ID
        {
            set
            {
                user_ID = value;
            }
            get
            {
                return user_ID;
            }
        }

        public string Produce_ID
        {
            set
            {
                produce_ID = value;
            }
            get
            {
                return produce_ID;
            }
        }



        public string DateTime
        {
            set
            {
                datetime = value;
            }
            get
            {
                return datetime;
            }
        }

        public int OPending
        {
            set
            {
                o_pending = value;
            }
            get
            {
                return o_pending;
            }
        }

        public int OReceived
        {
            set
            {
                o_received = value;
            }
            get
            {
                return o_received;
            }
        }

        public int OAccept
        {
            set
            {
                o_accept = value;
            }
            get
            {
                return o_accept;
            }
        }

        public int ODeny
        {
            set
            {
                o_deny = value;
            }
            get
            {
                return o_deny;
            }
        }



    }
}