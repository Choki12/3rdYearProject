﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AmaVeggieWcf
{
    public class User
    {

        private string UID { get; set; }
        private string name { get; set; }
        private string surname { get; set; }
        private string email { get; set; }
        private string address { get; set; }
        private string pass { get; set; }
        private string image { get; set; }
        private string cellnum { get; set; }
        private int auth { get; set; }
        private string usertype { get; set; } //farmer or customer or whatever

        public string UserID
        {
            set
            {
                UID = value;
            }

            get
            {
                return UID;
            }
        }

        public string Name
        {
            set
            {
                name = value;
            }

            get
            {
                return name;
            }
        }


        public string Surname
        {
            set
            {
                surname = value;
            }

            get
            {
                return surname;
            }
        }


        public string Email
        {
            set
            {
                email = value;
            }

            get
            {
                return email;
            }
        }


        public string Address
        {
            set
            {
                address = value;
            }

            get
            {
                return address;
            }
        }

        public string Password
        {
            set
            {
                pass = value;
            }

            get
            {
                return pass;
            }
        }

        public string Image
        {
            set
            {
                image = value;
            }

            get
            {
                return image;
            }
        }

        public string CellNum
        {
            set
            {
                cellnum = value;
            }

            get
            {
                return cellnum;
            }
        }

        public int Auth
        {
            set
            {
                auth = value;
            }

            get
            {
                return auth;
            }
        }

        public string UserType
        {
            set
            {
                usertype = value;
            }

            get
            {
                return usertype;
            }
        }

    }
}
